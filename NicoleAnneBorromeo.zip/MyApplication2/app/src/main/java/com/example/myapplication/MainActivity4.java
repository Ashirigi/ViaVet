package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity4 extends AppCompatActivity {
private Button btn;
private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        textView = (TextView)findViewById(R.id.textreturn);
        btn = (Button)findViewById(R.id.btn);

        textView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                openActivity1();
            }
        });

        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                setAppointment();
            }
        });

    }
    public void openActivity1(){
        Intent intent = new Intent(this, MainActivity3.class);
        startActivity(intent);
    }

    public void setAppointment(){
        Intent intent = new Intent(this, MainActivity5.class);
        startActivity(intent);
    }
}